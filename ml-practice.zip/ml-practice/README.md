# Машинное обучение — практические работы № 1–7

**Практические работы № 1–7 (уровень B)** — Дисциплина «Машинное обучение»
**ФИО:** ____________________ (впиши своё имя)  ·  **Группа:** ____

## Окружение
Выбран `venv` (встроенный в Python, не требует дополнительных программ) + `requirements.txt` с зафиксированными версиями библиотек.

```
python -m venv venv
.\venv\Scripts\Activate.ps1        # Windows PowerShell  (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
jupyter notebook
```

## Структура
```
data/        housing.csv (ПР-1–4, 7), reviews.csv (ПР-6)
notebooks/   PR1 … PR7 (выполнены, вывод ячеек сохранён)
src/         preprocessing.py (общий пайплайн), make_data.py, make_reviews.py (генерация данных)
```

## Работы
| № | Тема | Ноутбук |
|---|------|---------|
| 1 | Настройка окружения, первичный осмотр данных | `PR1_environment.ipynb` |
| 2 | Разведочный анализ данных (EDA) | `PR2_EDA.ipynb` |
| 3 | Пайплайн предобработки без утечки данных | `PR3_preprocessing.ipynb` |
| 4 | Линейная регрессия | `PR4_regression.ipynb` |
| 5 | Классификатор, метрики, подбор порога | `PR5_classification.ipynb` |
| 6 | Классификация текстов (TF-IDF + Naive Bayes) | `PR6_text_classification.ipynb` |
| 7 | Случайный лес | `PR7_random_forest.ipynb` |

## Данные
- `housing.csv`, `reviews.csv` — **синтетические** учебные данные (сгенерированы скриптами из `src/`), с намеренными дефектами.
- ПР-5 использует встроенный датасет `breast_cancer` из scikit-learn.
